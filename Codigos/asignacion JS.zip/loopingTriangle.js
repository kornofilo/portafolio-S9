//imprime un triangulo de 7 numerales en la base
for (let asterisco = "#"; asterisco <="#######"; asterisco+= "#"){
    console.log(asterisco)
}